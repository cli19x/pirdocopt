from distutils.core import setup

setup(
    name='Pir_Docopt',
    version='0.1dev',
    packages=['pirdocopt'],
    license='MIT License',
    long_description=open('README.rst').read(),
)
