from distutils.core import setup

setup(
    name='pirdocopt',
    version='1.0.4',
    packages=['pirdocopt'],
    license='MIT License',
    long_description=open('README.rst').read()
)
